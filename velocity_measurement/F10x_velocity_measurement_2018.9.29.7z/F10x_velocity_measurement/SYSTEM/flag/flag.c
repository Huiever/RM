#include "bsp.h"

/***********JSP ©copyright***********/
/*******Version 2.0 2018.07.26*******/
 
static int FLAGS_COUNT = 0;

Flag_t flags;
 
int Make_Flag(char *flag_name, int flag_value){
	if (FLAGS_COUNT >= MAX_FLAG_NUMBERS){
		printf("All the flags has been used out!\r\nYou can increase the macro definition 'MAX_FLAG_NUMBERS'.\r\n");
		return 0;
	}
	else{
		flags.flag_name[FLAGS_COUNT] = flag_name;
		flags.flag_value[FLAGS_COUNT] = flag_value;
		FLAGS_COUNT++;
		return 1;
	}
}
 
int Set_Flag_Value(char *flag_name){
	int i = 0;
	for (i = 0; i < FLAGS_COUNT; i++){
		if (flags.flag_name[i] == flag_name){
			flags.flag_value[i] = 1;
			break;
		}
	}
	if (i < FLAGS_COUNT){
		return 1;
	}
	else{
		printf("Not find the flag you set, please check your flag name.\r\n");
		return 0;
	}
}
 
int Reset_Flag_Value(char *flag_name){
	int i = 0;
	for (i = 0; i < FLAGS_COUNT; i++){
		if (flags.flag_name[i] == flag_name){
			flags.flag_value[i] = 0;
			break;
		}
	}
	if (i < FLAGS_COUNT){
		return 1;
	}
	else{
		printf("Not find the flag you reset, please check your flag name.\r\n");
		return 0;
	}
}
 
int Get_Flag_Value(char *flag_name){
	int i = 0;
	for (i = 0; i < FLAGS_COUNT; i++){
		if (flags.flag_name[i] == flag_name){
			return flags.flag_value[i];
			break;
		}
	}
	if (i < FLAGS_COUNT){
		return 1;
	}
	else{
		printf("Not find the flag, please check your flag name.\r\n");
		return 0;
	}
}

