#ifndef  __FLAG_H
#define  __FLAG_H

#define  MAX_FLAG_NUMBERS  50

typedef struct
{
	char *flag_name[MAX_FLAG_NUMBERS];
	int flag_value[MAX_FLAG_NUMBERS];
}Flag_t;

int Make_Flag(char *flag_name, int flag_value);
int Set_Flag_Value(char *flag_name);
int Reset_Flag_Value(char *flag_name);
int Get_Flag_Value(char *flag_name);

#endif
